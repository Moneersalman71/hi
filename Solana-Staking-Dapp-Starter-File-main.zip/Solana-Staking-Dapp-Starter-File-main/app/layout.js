import React from "react";

const layout = () => {
  return <div>layout</div>;
};

export default layout;
