import React from "react";

const useStakingContract = () => {
  return <div>useStakingContract</div>;
};

export default useStakingContract;
