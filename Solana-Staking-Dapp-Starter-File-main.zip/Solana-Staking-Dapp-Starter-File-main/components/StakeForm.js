import React from "react";

const StakeForm = () => {
  return <div>StakeForm</div>;
};

export default StakeForm;
