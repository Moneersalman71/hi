import React from "react";

const WalletConnect = () => {
  return <div>WalletConnect</div>;
};

export default WalletConnect;
