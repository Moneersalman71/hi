import React from "react";

const WithdrawTokens = () => {
  return <div>WithdrawTokens</div>;
};

export default WithdrawTokens;
