import React from "react";

const StakingStats = () => {
  return <div>StakingStats</div>;
};

export default StakingStats;
