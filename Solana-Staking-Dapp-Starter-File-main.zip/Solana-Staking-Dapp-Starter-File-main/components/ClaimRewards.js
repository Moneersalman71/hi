import React from "react";

const ClaimRewards = () => {
  return <div>ClaimRewards</div>;
};

export default ClaimRewards;
