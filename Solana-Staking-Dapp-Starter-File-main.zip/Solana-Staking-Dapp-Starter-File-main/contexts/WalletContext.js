import React from "react";

const WalletContext = () => {
  return <div>WalletContext</div>;
};

export default WalletContext;
